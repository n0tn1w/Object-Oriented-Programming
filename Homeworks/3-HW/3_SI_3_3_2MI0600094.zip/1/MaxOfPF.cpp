#include "MaxOfPF.h"

MaxOfPF::MaxOfPF(const PF* const* funcs, size_t size) : PFContainer(funcs, size) {}
MaxOfPF::MaxOfPF(PF**&& funcs, size_t size) : PFContainer(std::move(funcs), size) {}

Pair<int, bool>  MaxOfPF::operator()(int val) const {
    int* resultsFromFunctions = new int[_size];

    for(size_t i = 0; i < _size; i++) {

        Pair<int, bool> res = _data[i]->operator()(val);

        if(res.second() == false) {
        
            // Function is not defined 
            delete[] resultsFromFunctions;
            return Pair<int, bool>(0, false);
        
        } else {
            resultsFromFunctions[i] = res.first();
        }
    }

    Helper::SelectionSort(resultsFromFunctions, _size);
    
    if(isEmpty()) {
        throw std::out_of_range("No functions to be evaluated!");
    }
    Pair<int, bool> resultPair(resultsFromFunctions[_size - 1], true);

    delete[] resultsFromFunctions;

    return resultPair;
}

PF* MaxOfPF::clone() const {
    return new MaxOfPF(*this);
}
