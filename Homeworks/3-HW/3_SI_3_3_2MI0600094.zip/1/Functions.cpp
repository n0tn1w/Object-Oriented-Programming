#include "Functions.h"

DefinedInNumbersF::DefinedInNumbersF(Pair<int, int>* data, size_t size) { 
    _size = size;
    //std::memcpy(_data, data, size * sizeof(Pair<int, int>));
    for(size_t i = 0; i < size; i++) {
        _data[i] = data[i];
    }
}

Pair<int, bool>  DefinedInNumbersF::operator()(int val) const {
    for(size_t i = 0; i < _size; i++) {
        if(_data[i].first() == val) {
            return Pair<int, bool>(_data[i].second(), true);
        }
    }

    return Pair<int, bool>(0, false);
}

NotDefinedInNumbersF::NotDefinedInNumbersF(int* data, size_t size) {
    _size = size;
    std::memcpy(_data, data, size * sizeof(int));
}

Pair<int, bool>  NotDefinedInNumbersF::operator()(int val) const {
    for(size_t i = 0; i < _size; i++) {
        if(_data[i] == val) {
            return Pair<int, bool>(0, false);
        }
    }

    return Pair<int, bool>(val, true);
}

ReturnOneAndZeroF::ReturnOneAndZeroF(int* data, size_t size) {
    _size = size;
    std::memcpy(_data, data, size * sizeof(int));
}

Pair<int, bool>  ReturnOneAndZeroF::operator()(int val) const {
    for(size_t i = 0; i < _size; i++) {
        if(_data[i] == val) {
            return Pair<int, bool>(1, true);
        }
    }

    return Pair<int, bool>(0, true);
}
