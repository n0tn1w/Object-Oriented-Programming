#pragma once
#include <cstddef>

#include "Pair.hpp"

// Abstract class
class PF {

public:

    virtual Pair<int, bool> operator()(int) const = 0;
    virtual PF* clone() const = 0;
    virtual ~PF() = default;

};