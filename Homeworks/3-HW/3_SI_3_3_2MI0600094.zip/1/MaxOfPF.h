#pragma once
#include <stdexcept>

#include "PFContainer.h"
#include "Helper.h"


class MaxOfPF : public PFContainer {

public:

    MaxOfPF(const PF* const*, size_t);
    MaxOfPF(PF**&&, size_t);

    Pair<int, bool>  operator()(int) const override;
    PF* clone() const override;

};