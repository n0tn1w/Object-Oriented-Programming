#pragma once
#include <stdexcept>

#include "PFContainer.h"
#include "Helper.h"

class MinOfPF : public PFContainer {

public:

    MinOfPF(const PF* const*, size_t);
    MinOfPF(PF**&&, size_t);

    Pair<int, bool>  operator()(int) const;
    PF* clone() const ;

};