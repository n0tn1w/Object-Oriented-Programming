#pragma once
#include <stddef.h>
#include <algorithm>

//Interface
class Helper {

public:
    static void SelectionSort(int* arr, size_t size);
};